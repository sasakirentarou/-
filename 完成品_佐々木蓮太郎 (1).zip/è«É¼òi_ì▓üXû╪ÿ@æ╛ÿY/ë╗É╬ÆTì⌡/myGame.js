$(function(){
    //タイマー制御フラグ
    let stop = true;
    
    //制限時間変数
    var sec;
    var min;

    //移動制限カウンター
    var glidStopCountX = 0;
    var glidStopCountY = 0;

    //スライドカウント
    var slideCount = 0;

    //エリア
    var sand = '<img src="sand.jpg" class = "sandnum"/>';

    //player初期値
    $("td").eq(0).html($("#player"));

    //問題
    var question =
    ["生物の死骸や生活の跡が地層に残ったものを何というか。",
    "火成岩と堆積岩のうち、化石を含む可能性があるのはどちらの岩石か。",
    "示相化石とはどのような化石か。",
    "示相化石はどちらか選べ。",
    "新生代の化石はどちらか選べ。",
    "地盤を構成する様々な土の層を(　　　)という。",
    "かたい岩石が、日射や風雨などによって、しだいに表面からもろくなることを(　　　)という。",
    "地層が連続して堆積した場合、下の地層ほど（　　　）。",
    "風化によりもろくなった岩石が、水の流れによりけずりとられることを(　　　)という。",
    "浸食によってできたれきや砂や泥を、川が水の流れによって下流へ運ぶはたらきのことを(　　　)という。"];
    //正解
    var answer =
    ["化石",
    "堆積岩",
    "地層が堆積した当時の環境や場所を示す化石",
    "サンゴ",
    "ナウマンゾウ",
    "地層",
    "風化",
    "古い",
    "浸食",
    "運搬"];
    //不正解
    var miss =
    ["石灰岩",
    "火成岩",
    "地層が堆積した地質時代がわかる化石",
    "サンヨウチュウ",
    "アンモナイト",
    "地質",
    "山崩れ",
    "新しい",
    "摩擦",
    "搬送"]
    //解説
    var explanation = 
    [["答え：化石(かせき)" , "化石とは、過去の生物の体または生活の痕（あと）が","地層中に保存されたもの。" ],
     ["答え：堆積岩(たいせきがん)" , "堆積岩とは生物の死骸などが、流水や風の作用などで堆積して固まってできた岩石、","しばしば化石を含む。"],
     ["答え：地層が堆積した当時の環境や場所を示す化石" , "示相化石(しそうかせき)とは、","地層が堆積(たいせき)した当時の環境や場所を示す化石。"],
     ["答え：サンゴ" ,   "示相化石の例としては、","サンゴやアサリがあげられる。"],
     ["答え：ナウマンゾウ"  ,  "新生代(しんせいだい)とは、地質(ちしつ)時代の大区分の1つで、6600万年前から現在までの時代。","新生代の化石は、主にナウマンゾウ、ビカリアなどが挙げられる。"],
     ["答え：地層(ちそう)"  ,  "地盤を構成する様々な土の層を","地層という。"],
     ["答え：風化(ふうか)"  ,  "かたい岩石が、日射や風雨などによって、しだいに表面からもろくなることを","風化という。"],
     ["答え：古い"  ,  "地層が連続して堆積(たいせき)した場合、","下の地層ほど古い。"],
     ["答え：浸食(しんしょく)"  ,  "風化によりもろくなった岩石が、","水の流れによりけずりとられることを浸食という。"],
     ["答え：運搬(うんぱん)"  ,  "浸食によってできたれきや砂や泥を、川が水の流れによって","下流へ運ぶはたらきのことを運搬という。"]]
    
     //×●画像
    var answerImage = ['<img src="batu.png"/>','<img src="maru.png"/>'];

    //報酬名
    //多次元配列(複数エリア用)
    /* var itemName =  */ 
    /* [["アンモナイトの化石","葉っぱの化石","三葉虫の化石","恐竜の糞の化石"], */
    /*  ["ティラノの頭","恐竜の化石","プテラノドンの化石","恐竜の足跡の化石"]]; */
    var itemName = 
    ["アンモナイトの化石","葉っぱの化石","三葉虫の化石","恐竜の糞の化石",
     "ティラノの頭","恐竜の化石","プテラノドンの化石","恐竜の足跡の化石"];

    //報酬画像
    var itemImage = [
    '<img src="kaseki/k_anmo.png" id="kaseki"/>',
    '<img src="kaseki/k_leaf.png" id="kaseki"/>',
    '<img src="kaseki/k_sanyou.png" id="kaseki"/>',
    '<img src="kaseki/k_unko.png" id="kaseki"/>',
    '<img src="kaseki/k_head.png" id="kaseki"/>',
    '<img src="kaseki/k_kyouryu.png" id="kaseki"/>',
    '<img src="kaseki/k_putera.png" id="kaseki"/>',
    '<img src="kaseki/k_leg.png" id="kaseki"/>',];
    //報酬値段
    var itemPrice = [20000,5000,30000,15000,100000,200000,80000,50000];

    var randQuestion;//ランダムに表示される問題の配列用
    var randButton;//ランダムに表示されるボタン用
    var randItem;//ランダムに表示されるアイテム(報酬)の配列用
    var areaObj;//アクセスエリア保存用
    var itemflg = false;//アイテムフラグ
    var keepItem;//アイテム名保存用
    var keepPrice = [];//アイテム価値保存用
    var best = 0;//最高記録
    var playerPos = 0;//プレイヤーのグリッドカウント

    //ルール説明ボタン押下時
    $("#rule").click(function(){
        $(".title").hide();
        $(".ruleScreen").css('visibility','visible');
    });
    //スリック
    $(".slide_list").slick({
        pauseOnFocus:false,
        pauseOnHover:false,
        arrows:true,
        dots:true,
        swipe:false,
        speed: 200
    });
    $(".slick-next").click(function(){
        //5を超えたら0に戻る
        if(slideCount >= 4)
        {
            slideCount = 0;
        }
        else
        {
            slideCount++;
        }
        Rule();
    })
    $(".slick-prev").click(function(){
        //0より少なくなったら5に戻る
        if(slideCount <= 0)
        {
            slideCount = 4;
        }
        else
        {
            slideCount--;
        }
        Rule();
    })
    //戻るボタン押下時
    $("#back").click(function(){
        $(".ruleScreen").css('visibility','hidden');
        $(".title").show();
    });


    //開始ボタン押下時
    $("#start").click(function(){
        $(".title").hide();
        $(".game").show();

        //制限時間をセット
        min = 0;//分
        sec = 20;//秒

        //初期値0合わせ
        if(sec == 0){
            $('#timer').html(min + ':00');
        }
        else if(sec < 10){
            $('#timer').html(min + ':0' + sec);
        }
        else{
            $('#timer').html(min + ':' + sec);
        }
        
        stop = false;//タイマー開始
    });

    //カウントダウンタイマー
    setInterval(function() {
        if(!stop)
        {
            // タイマー終了
            if (min == 0 && sec <= 0) {
                sec = 0;
                $(".game").hide();
                $(".result").show();
                Result();
            }
            else
            {
                // カウントダウン
                sec -= 1;
            }

            if (sec < 0 && min > 0) {
            sec = 59;
            min -= 1;
            }

            // 0埋め
            var sec_number = ('0' + sec).slice(-2);
            var min_number = ('0' + min).slice(-1);

            //5秒になると赤く表示する
            if(sec <= 5)
            {
                $('#timer').html(min_number + ':' + sec_number).css('color','red');
            }
            else
            {
                $('#timer').html(min_number + ':' + sec_number);
            }
        }
    },1000); 

    
    //エリア出現
    setInterval(function(){
        if(!stop)
        {            
            //グリッド番号をランダムに格納
            var rand = Math.floor( Math.random() * 25 );

            if($('.sandnum').length < 3)
            {
                var cloneSand = $(sand).clone(); //複製
                $("td").eq(rand).append(cloneSand); //エリア出現
            }
        }
    },1000);

    //掘るボタン押下時
    $("#dig").click(function(){
        $(".firstmodal").show();//問題再表示
        $(".item").remove();//報酬表示削除

        //ランダムを格納
        randQuestion = Math.floor( Math.random() * question.length );//問題
        randButton = Math.floor(Math.random()*2 + 1);//ボタン

        var sandPos;
        
        //複数あるエリアをeachで特定
        $("td").each(function(index,element){

            //参照中のclass取得
            var elementClass = $($(element).html()).attr('class');

            //classがsandnumだったら現在のグリッド番号を取得
            if('sandnum' == elementClass)
            {
                sandPos = index;//エリアのポジション取得

                //当たり判定
                if(playerPos == sandPos)
                {
                    stop = true;//タイマーストップ

                    //idを格納
                    const modal = $("#js-modal");
                    const open = $("#js-open");
                    const overlay = $("#js-overlay");

                    //openクラス付与(モーダル表示)
                    modal.addClass("open"); 
                    overlay.addClass("open");
                    $(".answerbutton").show();//ボタン表示

                    $("#question").text(question[randQuestion]);//問題を表示
        
                    //正解と不正解のボタンをランダムで入れ替え
                    if(randButton == 1)
                    {
                        $("#answer1").text(answer[randQuestion]);
                        $("#answer2").text(miss[randQuestion]);
                    }
                    else
                    {
                        $("#answer1").text(miss[randQuestion]);
                        $("#answer2").text(answer[randQuestion]);
                    }
                    return false;//当たったので抜け出す
                }
            }
        });
    });

    //回答ボタン押下時
    $(".answerbutton").click(function(){
        $(".answerbutton").hide();//ボタン削除

        var textget = $(this).text();//押下したボタンの問題を取得
        var numget;

        //答えをforで特定
        for(var i = 0;i < question.length; i++)
        {
            //どの問題の答えかを探す
            if(answer[i] == textget)
            {
                numget = i;//答えの番号を格納
                break;
            }
        }

        //答えとボタンの問題が一致していたら正解
        if(answer[numget] == textget)
        {
            $("#hantei").append(answerImage[1]);//正解
            $("#next").show()//続けるボタン表示
            itemflg = true;//報酬フラグをtrue
        }
        else
        {
            $("#hantei").append(answerImage[0]);//不正解

            stop = true;

            //divを繰り返して追加(改行)
            for(var i = 0;i<=2;i++)
            {
                $("#expbox").show().append("<div>"+explanation[randQuestion][i]+"</div>");
            }

            $("#expbox div:first-child").addClass("answerstyle");//答え~にクラス付与
            $("#next").show()//続けるボタン表示
        }    
    });

    //続けるボタン押下時
    $("#next").click(function(){
        //×●画像は邪魔なので先に削除
        $("#hantei img:first-child").remove();
        
        //アイテム配列用変数にランダムを格納
        randItem = Math.floor( Math.random() * itemPrice.length );

        if(itemflg == true)//報酬獲得画面
        {
            $(".firstmodal").hide();//問題などを非表示

            keepPrice.push(itemPrice[randItem]);

            //報酬表示追加
            $(".modal").append(
                '<div class="item">'+ '価格：' + itemPrice[randItem] + '円' +
                '<br>' +  itemImage[randItem] + '</div>'
            );

            //下のboxにitem名を表示
            $("#expbox").show().append(
                '<div class="item">' + itemName[randItem] + 
                "をゲットした！！" + '</div>'
            );
            
            //文として保存
            $(".keephide").append('<li>' + itemName[randItem] + '</li>');

            itemflg = false;//次の続ける処理でelseに行けるようfalseにする
        }
        else
        {
            const modal = $("#js-modal");
            const open = $("#js-open");
            const overlay = $("#js-overlay");

            stop = false;
            modal.removeClass("open"); // modalクラスからopenクラスを外す
            overlay.removeClass("open"); // overlayクラスからopenクラスを外す
            $("#player").siblings(".sandnum").remove();//エリアを削除
            $("#expbox").hide();//次も使うので非表示
            $("#expbox").children().remove();//解説部分は追加するので削除
            $("#next").hide();//続けるボタンを非表示
        }
    });
    
    //リザルトからタイトル
    $("#nexttitle").click(function(){
        $(".result").hide();//リザルト非表示
        $(".title").show();//タイトル表示

        $(".itemlist li").remove();//アイテムリスト内削除
        $(".keephide li").remove();//アイテム名保存リスト内削除
        keepPrice = [];//アイテム価値配列初期化

        glidStopCountX = 0;//移動カウンター初期化
        glidStopCountY = 0;

        playerPos = 0;//プレイヤーポジション初期化
        $("td").eq(playerPos).append($("#player"));//プレイヤー再配置

        //グリッドからエリアを見つけて削除
        $("td").each(function(index,element){
            //参照中のclass取得
            var elementClass = $($(element).html()).attr('class');
            //classがsandnumだったら現在のグリッド番号を取得
            if('sandnum' == elementClass)
            {
                $("td").eq(index).html("");
            }
        });
    });



    //移動
    $(".move").click(function(){
        //グリッドからプレイヤーを見つける
        $("table tr td").each(function(index,element){

            //参照中のid取得
            var elementId = $($(element).html()).attr('id');

            //idがplayerだったら現在のグリッド番号を取得
            if('player' == elementId)
            {
                playerPos = index;
            }
        });        
    });

    //上
    $("#up").click(function(){
        glidStopCountY--;

        //移動制限
        if(glidStopCountY < 0)
        {
            doBounce($("#player"), 2, '10px', 100);   
            glidStopCountY++;
        }
        else
        {
            playerPos -= 5;
            $("td").eq(playerPos).append($("#player"));
        }
    });
    //下
    $("#down").click(function(){
        glidStopCountY++;

        //移動制限
        if(glidStopCountY > 4)
        {
            doBounce($("#player"), 2, '10px', 100);   
            glidStopCountY--;
        }
        else
        {
            playerPos += 5;
            $("td").eq(playerPos).append($("#player"));
        }
    });
    //右
    $("#right").click(function(){
        glidStopCountX++;

        //移動制限
        if(glidStopCountX > 4)
        {
            doShake($("#player"), 2, '10px', 100);   
            glidStopCountX--;
        }
        else
        {
            playerPos += 1;
            $("td").eq(playerPos).append($("#player"));
        }
        
    });
    //左
    $("#left").click(function(){
        glidStopCountX--;

        //移動制限
        if(glidStopCountX < 0)
        {
            doShake($("#player"), 2, '10px', 100);   
            glidStopCountX++;
        }
        else
        {
            playerPos -= 1;
            $("td").eq(playerPos).append($("#player"));
        }
    });    
    

    //バウンド関数
    function doBounce(element, times, distance, speed) {
        for(var i = 0; i < times; i++) {
            element.animate({marginTop: '-='+distance}, speed)
                .animate({marginTop: '+='+distance}, speed);
        }
    }
    //シェイク関数
    function doShake(element, times, distance, speed) {
        for(var i = 0; i < times; i++) {
            element.animate({"marginLeft": '-='+distance}, speed)
                .animate({"marginLeft": '+='+distance}, speed);
        }
    }

    //リザルト関数
    function Result() {
        stop = true;
        var totalPrice = 0;
        var listnum = 1;
        var oldnum = 0;

        $(".keephide li").each(function(index,element)
        {
            keepItem = $(element).text();

            $('.itemlist').append('<li>' + keepItem + '</li>');
            totalPrice += keepPrice[index];
        });

        $("#total").text('合計額：'+totalPrice+'円');

        if(best < totalPrice)
        {
            best = totalPrice;
        }
        $("#bestrecord").html('最高記録:'+ best + '円');
    }

    //ルール説明のswitch文
    function Rule() {
        switch(slideCount)
        {
        case 0:
            $("#ruleExp").html("1.左上の制限時間が0になると終了、左のボタンで移動または掘る");
            break;
        case 1:
            $("#ruleExp").html("2.砂山を掘ると制限時間が停止、問題が出題される");
            break;
        case 2:
            $("#ruleExp").html("3.間違えると答えと解説で教えてくれる");
            break;
        case 3:
            $("#ruleExp").html("4.正解するとランダムで化石がもらえる、化石によって価値が違う");
            break;
        case 4:
            $("#ruleExp").html("5.結果画面では手に入れた化石と合計金額が表示される。新記録を目指そう！");
            break;
        }
    }
});
